package com.dailyflow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.content.Context

data class Habit(val icon: String, val title: String)

private val habits = listOf(
    Habit("🌅", "بیدار شدن"),
    Habit("💧", "۱ لیوان آب"),
    Habit("🪥", "مسواک صبح"),
    Habit("🧴", "شستن صورت"),
    Habit("🍽️", "صبحانه"),
    Habit("🏫", "مدرسه / کلاس‌ها"),
    Habit("🍽️", "ناهار"),
    Habit("🪥", "مسواک ظهر"),
    Habit("😴", "خواب ظهر: ۳۰ دقیقه"),
    Habit("📚", "ریاضی"),
    Habit("📐", "هندسه"),
    Habit("📘", "فیزیک"),
    Habit("🧪", "شیمی"),
    Habit("🍌", "میان‌وعده عصر"),
    Habit("🏃", "ورزش: ۳۰–۶۰ دقیقه"),
    Habit("🚿", "حمام / بهداشت شخصی"),
    Habit("🪒", "سیبیل / موهای زائد"),
    Habit("🍽️", "شام"),
    Habit("🔄", "مرور درس‌های همان روز"),
    Habit("✏️", "حل تمرین و تست"),
    Habit("☀️", "هوای آزاد / استراحت"),
    Habit("💧", "تکمیل ۶–۸ لیوان آب"),
    Habit("📵", "کنار گذاشتن گوشی قبل خواب"),
    Habit("🪥", "مسواک شب"),
    Habit("🧴", "شستن صورت شب"),
    Habit("🌙", "خواب شب: ۷.۵ ساعت")
)

private fun todayKey(): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

class HabitStore(context: Context) {
    private val prefs = context.getSharedPreferences("dailyflow", Context.MODE_PRIVATE)

    fun load(): MutableSet<String> {
        val savedDate = prefs.getString("date", "")
        if (savedDate != todayKey()) {
            prefs.edit().clear().putString("date", todayKey()).apply()
            return mutableSetOf()
        }
        return prefs.getStringSet("done", emptySet())?.toMutableSet() ?: mutableSetOf()
    }

    fun save(done: Set<String>) {
        prefs.edit().putString("date", todayKey()).putStringSet("done", done).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DailyFlowApp() }
    }
}

@Composable
fun DailyFlowApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { HabitStore(context) }
    var dark by remember { mutableStateOf(true) }
    val done = remember { mutableStateOf(store.load()) }

    val completed = done.value.size
    val total = habits.size
    val progress = completed.toFloat() / total.toFloat()

    val bg = if (dark) Color(0xFF0E1117) else Color(0xFFF5F7FA)
    val card = if (dark) Color(0xFF171C25) else Color.White
    val primary = if (dark) Color(0xFF7C8CFF) else Color(0xFF536DFE)
    val text = if (dark) Color(0xFFF3F5F7) else Color(0xFF17202A)
    val secondary = if (dark) Color(0xFF9CA6B5) else Color(0xFF667085)

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            primary = primary, background = bg, surface = card
        ) else lightColorScheme(
            primary = primary, background = bg, surface = card
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = bg) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("DailyFlow", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = text)
                        Text("امروزت رو بساز ✨", fontSize = 14.sp, color = secondary)
                    }
                    Text(
                        if (dark) "☀️" else "🌙",
                        fontSize = 22.sp,
                        modifier = Modifier
                            .clickable { dark = !dark }
                            .padding(10.dp)
                    )
                }

                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    colors = CardDefaults.cardColors(containerColor = card),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("پیشرفت امروز", fontSize = 15.sp, color = secondary)
                                Text("$completed از $total کار", fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold, color = text)
                            }
                            Text("${(progress * 100).toInt()}%", fontSize = 25.sp,
                                fontWeight = FontWeight.Bold, color = primary)
                        }
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(9.dp),
                            color = primary,
                            trackColor = if (dark) Color(0xFF292F3A) else Color(0xFFE4E7EC)
                        )
                    }
                }

                if (completed == total) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        colors = CardDefaults.cardColors(containerColor = primary),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            "امروز رو کامل کردی! 🎉",
                            modifier = Modifier.fillMaxWidth().padding(18.dp),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    itemsIndexed(habits) { index, habit ->
                        val key = "$index"
                        HabitCard(
                            habit = habit,
                            checked = done.value.contains(key),
                            card = card,
                            text = text,
                            secondary = secondary,
                            primary = primary
                        ) {
                            val newSet = done.value.toMutableSet()
                            if (!newSet.add(key)) newSet.remove(key)
                            done.value = newSet
                            store.save(newSet)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HabitCard(
    habit: Habit,
    checked: Boolean,
    card: Color,
    text: Color,
    secondary: Color,
    primary: Color,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (checked) 1.015f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "cardScale"
    )

    Card(
        modifier = Modifier.fillMaxWidth().scale(scale).clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (checked) primary.copy(alpha = 0.16f) else card
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(habit.icon, fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Text(
                habit.title,
                modifier = Modifier.weight(1f),
                fontSize = 16.sp,
                fontWeight = if (checked) FontWeight.SemiBold else FontWeight.Normal,
                color = if (checked) text.copy(alpha = .75f) else text
            )

            Box(
                modifier = Modifier.size(31.dp).background(
                    if (checked) primary else Color.Transparent,
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                if (checked) {
                    AnimatedVisibility(
                        visible = checked,
                        enter = fadeIn() + scaleIn()
                    ) {
                        Text("✓", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Surface(
                        modifier = Modifier.size(25.dp),
                        shape = CircleShape,
                        color = Color.Transparent,
                        border = androidx.compose.foundation.BorderStroke(2.dp, secondary.copy(alpha = .7f))
                    ) {}
                }
            }
        }
    }
}
